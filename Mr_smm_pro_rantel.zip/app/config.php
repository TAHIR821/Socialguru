<?php
define('PATH', realpath('.'));
define('SUBFOLDER', false);
define('URL', 'https://bigrocksmm.shop' );
define('STYLESHEETS_URL', '//bigrocksmm.shop' );
date_default_timezone_set('Asia/Kolkata');

/*
 ini_set("display_errors","1");
error_reporting(E_ALL);   */

error_reporting(0);
return [
  'db' => [
    'name'    =>  'bigrocks_smm' ,
    'host'    =>  'localhost',
    'user'    =>  'bigrocks_smm' ,
    'pass'    =>  'bigrocks_smm' ,
    'charset' =>  'utf8mb4'
  ]
];

?>